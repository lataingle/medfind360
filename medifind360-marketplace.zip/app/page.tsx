import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Search,
  MapPin,
  Shield,
  Star,
  Users,
  Stethoscope,
  Heart,
  Activity,
  Phone,
  Mail,
  Clock,
  Award,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-50 to-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-teal-600" />
              <span className="text-2xl font-bold text-gray-900">MediFind360</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/directory" className="text-gray-700 hover:text-teal-600 font-medium">
                Directory
              </Link>
              <Link href="/equipment" className="text-gray-700 hover:text-teal-600 font-medium">
                Equipment
              </Link>
              <Link href="/insurance" className="text-gray-700 hover:text-teal-600 font-medium">
                Insurance
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-teal-600 font-medium">
                About
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/auth/login">
                <Button variant="outline">Sign In</Button>
              </Link>
              <Link href="/auth/signup">
                <Button className="bg-teal-600 hover:bg-teal-700">Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight">
                Your Complete
                <span className="text-teal-600"> Healthcare</span>
                <br />
                Directory
              </h1>
              <p className="text-xl text-gray-600 mt-6 leading-relaxed">
                Find verified clinics, compare medical equipment, and explore insurance options all in one place. Your
                health journey starts here.
              </p>

              {/* Search Bar */}
              <div className="mt-8 bg-white p-6 rounded-2xl shadow-lg border">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input placeholder="Search doctors, clinics, or specialties..." className="pl-10 h-12 text-lg" />
                  </div>
                  <div className="flex-1 relative">
                    <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input placeholder="Enter your location..." className="pl-10 h-12 text-lg" />
                  </div>
                  <Button className="h-12 px-8 bg-teal-600 hover:bg-teal-700 text-lg">Find Care</Button>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="mt-8 grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-teal-600">50K+</div>
                  <div className="text-sm text-gray-600">Healthcare Providers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-teal-600">1M+</div>
                  <div className="text-sm text-gray-600">Patient Reviews</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-teal-600">24/7</div>
                  <div className="text-sm text-gray-600">Support Available</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <Image
                src="/images/hero-healthcare.jpg"
                alt="Healthcare professionals and medical equipment"
                width={600}
                height={600}
                className="rounded-2xl shadow-2xl"
                priority
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <Shield className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">HIPAA Compliant</div>
                    <div className="text-sm text-gray-600">Your data is secure</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">Everything You Need for Better Healthcare</h2>
            <p className="text-xl text-gray-600 mt-4">
              Comprehensive tools and resources to make informed healthcare decisions
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center pb-4">
                <div className="bg-teal-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Stethoscope className="h-8 w-8 text-teal-600" />
                </div>
                <CardTitle className="text-xl">Smart Directory</CardTitle>
                <CardDescription className="text-base">
                  Find verified healthcare providers with real-time availability and patient reviews
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 mr-2" />
                    Real patient reviews
                  </li>
                  <li className="flex items-center">
                    <MapPin className="h-4 w-4 text-teal-500 mr-2" />
                    GPS location finder
                  </li>
                  <li className="flex items-center">
                    <Clock className="h-4 w-4 text-blue-500 mr-2" />
                    Real-time availability
                  </li>
                </ul>
                <Link href="/directory">
                  <Button className="w-full mt-4 bg-teal-600 hover:bg-teal-700">Explore Directory</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center pb-4">
                <div className="bg-coral-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Activity className="h-8 w-8 text-coral-600" />
                </div>
                <CardTitle className="text-xl">Equipment Marketplace</CardTitle>
                <CardDescription className="text-base">
                  Compare and purchase medical equipment from trusted suppliers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Award className="h-4 w-4 text-purple-500 mr-2" />
                    Expert recommendations
                  </li>
                  <li className="flex items-center">
                    <Shield className="h-4 w-4 text-green-500 mr-2" />
                    Verified suppliers
                  </li>
                  <li className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 mr-2" />
                    Best price guarantee
                  </li>
                </ul>
                <Link href="/equipment">
                  <Button className="w-full mt-4 bg-coral-600 hover:bg-coral-700">Shop Equipment</Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="text-center pb-4">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Insurance Hub</CardTitle>
                <CardDescription className="text-base">
                  Compare health insurance plans and find the best coverage for your needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Users className="h-4 w-4 text-indigo-500 mr-2" />
                    All major insurers
                  </li>
                  <li className="flex items-center">
                    <Activity className="h-4 w-4 text-green-500 mr-2" />
                    Plan comparison tool
                  </li>
                  <li className="flex items-center">
                    <Phone className="h-4 w-4 text-blue-500 mr-2" />
                    Expert consultation
                  </li>
                </ul>
                <Link href="/insurance">
                  <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">Compare Plans</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-teal-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Stay Updated with Healthcare News</h2>
          <p className="text-xl text-teal-100 mb-8">
            Get the latest healthcare insights, provider updates, and exclusive offers delivered to your inbox
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input placeholder="Enter your email address" className="bg-white h-12 text-lg flex-1" />
            <Button className="bg-coral-600 hover:bg-coral-700 h-12 px-8">Subscribe</Button>
          </div>
          <p className="text-sm text-teal-200 mt-4">We respect your privacy. Unsubscribe at any time.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Heart className="h-8 w-8 text-teal-400" />
                <span className="text-2xl font-bold">MediFind360</span>
              </div>
              <p className="text-gray-400 mb-4">
                Your trusted partner in finding quality healthcare providers and medical resources.
              </p>
              <div className="flex space-x-4">
                <Mail className="h-5 w-5 text-gray-400" />
                <Phone className="h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/directory" className="hover:text-white">
                    Provider Directory
                  </Link>
                </li>
                <li>
                  <Link href="/equipment" className="hover:text-white">
                    Medical Equipment
                  </Link>
                </li>
                <li>
                  <Link href="/insurance" className="hover:text-white">
                    Insurance Plans
                  </Link>
                </li>
                <li>
                  <Link href="/telemedicine" className="hover:text-white">
                    Telemedicine
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/help" className="hover:text-white">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-white">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/partners" className="hover:text-white">
                    Partners
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 MediFind360. All rights reserved. HIPAA Compliant Healthcare Directory.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
