"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, Check, Phone, Users, Heart, Star, Calculator } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const insurancePlans = [
  {
    id: 1,
    provider: "Blue Cross Blue Shield",
    planName: "Silver Advantage",
    type: "HMO",
    monthlyPremium: 285,
    deductible: 2500,
    outOfPocketMax: 7000,
    rating: 4.6,
    coverage: ["Primary Care", "Specialist Visits", "Emergency Care", "Prescription Drugs"],
    network: "Large Network",
    logo: "/images/insurance-logos.jpg",
    popular: true,
  },
  {
    id: 2,
    provider: "UnitedHealthcare",
    planName: "Gold Select",
    type: "PPO",
    monthlyPremium: 425,
    deductible: 1500,
    outOfPocketMax: 6000,
    rating: 4.8,
    coverage: ["Primary Care", "Specialist Visits", "Emergency Care", "Mental Health", "Prescription Drugs"],
    network: "Nationwide Network",
    logo: "/images/insurance-logos.jpg",
    popular: false,
  },
  {
    id: 3,
    provider: "Aetna",
    planName: "Bronze Basic",
    type: "HMO",
    monthlyPremium: 195,
    deductible: 5000,
    outOfPocketMax: 8500,
    rating: 4.4,
    coverage: ["Emergency Care", "Preventive Care", "Basic Prescription Coverage"],
    network: "Regional Network",
    logo: "/images/insurance-logos.jpg",
    popular: false,
  },
]

const medicareOptions = [
  {
    type: "Medicare Part A",
    description: "Hospital Insurance",
    coverage: "Inpatient hospital care, skilled nursing facility care",
    cost: "Most people pay no premium",
  },
  {
    type: "Medicare Part B",
    description: "Medical Insurance",
    coverage: "Doctor visits, outpatient care, medical supplies",
    cost: "Standard premium: $174.70/month",
  },
  {
    type: "Medicare Part C",
    description: "Medicare Advantage",
    coverage: "All-in-one alternative to Original Medicare",
    cost: "Varies by plan",
  },
  {
    type: "Medicare Part D",
    description: "Prescription Drug Coverage",
    coverage: "Prescription medications",
    cost: "Varies by plan",
  },
]

export default function InsurancePage() {
  const [zipCode, setZipCode] = useState("")
  const [age, setAge] = useState("")
  const [income, setIncome] = useState("")
  const [planType, setPlanType] = useState("")

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">M</span>
              </div>
              <span className="text-xl font-bold text-gray-900">MediFind360</span>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/directory" className="text-gray-700 hover:text-teal-600">
                Directory
              </Link>
              <Link href="/equipment" className="text-gray-700 hover:text-teal-600">
                Equipment
              </Link>
              <Link href="/insurance" className="text-blue-600 font-medium">
                Insurance
              </Link>
            </nav>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 mb-8 text-white">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl font-bold mb-4">Health Insurance Hub</h1>
              <p className="text-xl mb-6 text-blue-100">
                Compare health insurance plans, understand Medicare options, and find the perfect coverage for your
                healthcare needs.
              </p>
              <div className="flex items-center space-x-4">
                <Badge className="bg-white text-blue-600">Free Consultation</Badge>
                <Badge className="bg-white text-blue-600">Expert Guidance</Badge>
              </div>
            </div>
            <div className="text-center">
              <Image
                src="/images/insurance-consultation.jpg"
                alt="Health insurance comparison"
                width={400}
                height={300}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>

        {/* Plan Finder */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Find Your Perfect Plan</h2>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <Input placeholder="ZIP Code" value={zipCode} onChange={(e) => setZipCode(e.target.value)} />

            <Select value={age} onValueChange={setAge}>
              <SelectTrigger>
                <SelectValue placeholder="Age Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="18-25">18-25</SelectItem>
                <SelectItem value="26-35">26-35</SelectItem>
                <SelectItem value="36-45">36-45</SelectItem>
                <SelectItem value="46-55">46-55</SelectItem>
                <SelectItem value="56-64">56-64</SelectItem>
                <SelectItem value="65+">65+</SelectItem>
              </SelectContent>
            </Select>

            <Select value={income} onValueChange={setIncome}>
              <SelectTrigger>
                <SelectValue placeholder="Household Income" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="under-30k">Under $30,000</SelectItem>
                <SelectItem value="30k-50k">$30,000 - $50,000</SelectItem>
                <SelectItem value="50k-75k">$50,000 - $75,000</SelectItem>
                <SelectItem value="75k-100k">$75,000 - $100,000</SelectItem>
                <SelectItem value="over-100k">Over $100,000</SelectItem>
              </SelectContent>
            </Select>

            <Select value={planType} onValueChange={setPlanType}>
              <SelectTrigger>
                <SelectValue placeholder="Plan Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hmo">HMO</SelectItem>
                <SelectItem value="ppo">PPO</SelectItem>
                <SelectItem value="epo">EPO</SelectItem>
                <SelectItem value="pos">POS</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-4">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Calculator className="h-4 w-4 mr-2" />
              Compare Plans
            </Button>
            <Button variant="outline">
              <Phone className="h-4 w-4 mr-2" />
              Speak with Expert
            </Button>
          </div>
        </div>

        {/* Insurance Options Tabs */}
        <Tabs defaultValue="marketplace" className="mb-8">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="marketplace">Marketplace Plans</TabsTrigger>
            <TabsTrigger value="medicare">Medicare</TabsTrigger>
            <TabsTrigger value="medicaid">Medicaid</TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace" className="mt-6">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold text-gray-900">Available Health Insurance Plans</h3>
                <Select defaultValue="premium">
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="premium">Sort by Premium</SelectItem>
                    <SelectItem value="deductible">Sort by Deductible</SelectItem>
                    <SelectItem value="rating">Sort by Rating</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {insurancePlans.map((plan) => (
                <Card key={plan.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row gap-6">
                      <div className="lg:w-32 flex-shrink-0">
                        <Image
                          src={plan.logo || "/placeholder.svg"}
                          alt={plan.provider}
                          width={120}
                          height={60}
                          className="w-full h-16 object-contain"
                        />
                      </div>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-xl font-semibold text-gray-900 mb-1">
                              {plan.planName}
                              {plan.popular && <Badge className="ml-2 bg-blue-600">Most Popular</Badge>}
                            </h3>
                            <p className="text-gray-600">
                              {plan.provider} • {plan.type}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-blue-600">${plan.monthlyPremium}/mo</div>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-400 fill-current" />
                              <span className="ml-1 text-sm">{plan.rating}</span>
                            </div>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-600">Deductible</div>
                            <div className="font-semibold">${plan.deductible.toLocaleString()}</div>
                          </div>
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-600">Out-of-Pocket Max</div>
                            <div className="font-semibold">${plan.outOfPocketMax.toLocaleString()}</div>
                          </div>
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <div className="text-sm text-gray-600">Network</div>
                            <div className="font-semibold">{plan.network}</div>
                          </div>
                        </div>

                        <div className="mb-4">
                          <h4 className="font-semibold mb-2">Coverage Includes:</h4>
                          <div className="flex flex-wrap gap-2">
                            {plan.coverage.map((item) => (
                              <Badge key={item} variant="outline" className="flex items-center">
                                <Check className="h-3 w-3 mr-1 text-green-500" />
                                {item}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex gap-3">
                          <Button className="bg-blue-600 hover:bg-blue-700">View Plan Details</Button>
                          <Button variant="outline">Get Quote</Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="medicare" className="mt-6">
            <div className="space-y-6">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Understanding Medicare</h3>
                <p className="text-lg text-gray-600">
                  Medicare provides health coverage for people 65 and older or with certain disabilities
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {medicareOptions.map((option) => (
                  <Card key={option.type}>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Shield className="h-6 w-6 text-blue-600 mr-2" />
                        {option.type}
                      </CardTitle>
                      <CardDescription className="text-lg">{option.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">{option.coverage}</p>
                      <div className="bg-blue-50 p-3 rounded-lg mb-4">
                        <div className="font-semibold text-blue-900">Cost: {option.cost}</div>
                      </div>
                      <Button variant="outline" className="w-full">
                        Learn More
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <h4 className="text-xl font-semibold text-blue-900 mb-2">Need Help with Medicare?</h4>
                <p className="text-blue-700 mb-4">
                  Our Medicare specialists can help you understand your options and enroll in the right plan
                </p>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Phone className="h-4 w-4 mr-2" />
                  Schedule Medicare Consultation
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="medicaid" className="mt-6">
            <div className="space-y-6">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Medicaid Information</h3>
                <p className="text-lg text-gray-600">
                  Medicaid provides health coverage for eligible low-income adults, children, pregnant women, elderly
                  adults and people with disabilities
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Users className="h-6 w-6 text-green-600 mr-2" />
                      Eligibility Requirements
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Income below federal poverty level
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        U.S. citizen or qualified immigrant
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Resident of the state where applying
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Meet additional state requirements
                      </li>
                    </ul>
                    <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">Check Eligibility</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Heart className="h-6 w-6 text-red-600 mr-2" />
                      Coverage Benefits
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Doctor visits and hospital care
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Prescription medications
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Mental health services
                      </li>
                      <li className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        Preventive care and screenings
                      </li>
                    </ul>
                    <Button variant="outline" className="w-full mt-4">
                      View Full Benefits
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Educational Resources */}
        <div className="bg-white rounded-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Insurance Education Center</h2>
            <p className="text-xl text-gray-600">
              Learn about health insurance terms, coverage options, and how to make the best choice for your needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle>Understanding Deductibles</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Learn how deductibles work and how they affect your out-of-pocket costs for healthcare services.
                </p>
                <Button variant="outline" className="w-full">
                  Read Guide
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-green-200">
              <CardHeader>
                <CardTitle>HMO vs PPO vs EPO</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Compare different plan types to understand which network structure works best for your lifestyle.
                </p>
                <Button variant="outline" className="w-full">
                  Compare Plans
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-purple-200">
              <CardHeader>
                <CardTitle>Open Enrollment Guide</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Everything you need to know about enrollment periods and special qualifying events.
                </p>
                <Button variant="outline" className="w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
