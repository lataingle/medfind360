import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Lock, Eye, UserCheck, FileText, Mail } from "lucide-react"
import Link from "next/link"

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Link href="/" className="flex items-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">M</span>
            </div>
            <span className="text-xl font-bold text-gray-900">MediFind360</span>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Privacy Policy</h1>
          <p className="text-gray-600 mt-2">Last updated: January 2024</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* HIPAA Compliance Notice */}
        <Card className="mb-8 border-green-200 bg-green-50">
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              <Shield className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <h2 className="text-xl font-bold text-green-900">HIPAA Compliant Platform</h2>
                <p className="text-green-700">Your health information is protected under federal law</p>
              </div>
            </div>
            <p className="text-green-800">
              MediFind360 is committed to protecting your health information in accordance with the Health Insurance
              Portability and Accountability Act (HIPAA) and other applicable privacy laws.
            </p>
          </CardContent>
        </Card>

        {/* Information We Collect */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-6 w-6 text-blue-600 mr-2" />
              Information We Collect
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg mb-3">Personal Information</h3>
              <ul className="space-y-2 text-gray-700">
                <li>
                  • <strong>Account Information:</strong> Name, email address, phone number, date of birth
                </li>
                <li>
                  • <strong>Location Data:</strong> Address, ZIP code for provider recommendations
                </li>
                <li>
                  • <strong>Contact Preferences:</strong> Newsletter subscriptions, promotional communications
                </li>
                <li>
                  • <strong>Authentication Data:</strong> Encrypted passwords, login credentials
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-3">Usage Information</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Search queries and provider interactions</li>
                <li>• Pages visited and time spent on our platform</li>
                <li>• Device information and browser type</li>
                <li>• IP address and general location data</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-3">Health-Related Information</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Healthcare provider searches and preferences</li>
                <li>• Insurance information (when provided)</li>
                <li>• Medical equipment interests and purchases</li>
                <li>
                  • <strong>Note:</strong> We do not collect detailed medical records or diagnoses
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* How We Use Your Information */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <UserCheck className="h-6 w-6 text-purple-600 mr-2" />
              How We Use Your Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Service Provision</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Personalized provider recommendations</li>
                  <li>• Location-based search results</li>
                  <li>• Account management and support</li>
                  <li>• Insurance plan comparisons</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Communication</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Service updates and notifications</li>
                  <li>• Newsletter content (with consent)</li>
                  <li>• Promotional offers (with consent)</li>
                  <li>• Customer support responses</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Platform Improvement</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Analytics and usage patterns</li>
                  <li>• Feature development</li>
                  <li>• Quality assurance</li>
                  <li>• Security monitoring</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Legal Compliance</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• HIPAA compliance requirements</li>
                  <li>• State and federal regulations</li>
                  <li>• Fraud prevention</li>
                  <li>• Legal process compliance</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Information Sharing */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="h-6 w-6 text-orange-600 mr-2" />
              Information Sharing and Disclosure
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-semibold text-red-900 mb-2">We DO NOT sell your personal health information</h4>
              <p className="text-red-800 text-sm">
                Your health-related data is never sold to third parties for marketing purposes.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-3">Limited Sharing Scenarios:</h4>
              <ul className="space-y-3 text-gray-700">
                <li>
                  <strong>Service Providers:</strong> Trusted partners who help operate our platform (hosting,
                  analytics, customer support) under strict confidentiality agreements
                </li>
                <li>
                  <strong>Healthcare Providers:</strong> Only when you explicitly request to share information for
                  appointment scheduling or consultations
                </li>
                <li>
                  <strong>Legal Requirements:</strong> When required by law, court order, or to protect rights and
                  safety
                </li>
                <li>
                  <strong>Business Transfers:</strong> In the event of a merger or acquisition, with continued privacy
                  protection commitments
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Data Security */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lock className="h-6 w-6 text-green-600 mr-2" />
              Data Security and Protection
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Technical Safeguards</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• SSL/TLS encryption for data transmission</li>
                  <li>• AES-256 encryption for stored data</li>
                  <li>• Regular security audits and penetration testing</li>
                  <li>• Multi-factor authentication options</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Administrative Safeguards</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Employee privacy training programs</li>
                  <li>• Access controls and authorization limits</li>
                  <li>• Regular privacy impact assessments</li>
                  <li>• Incident response procedures</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Physical Safeguards</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Secure data centers with 24/7 monitoring</li>
                  <li>• Biometric access controls</li>
                  <li>• Environmental controls and backup systems</li>
                  <li>• Secure disposal of hardware</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Compliance Standards</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• HIPAA Security Rule compliance</li>
                  <li>• SOC 2 Type II certification</li>
                  <li>• GDPR compliance for EU users</li>
                  <li>• CCPA compliance for California residents</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Your Rights */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Your Privacy Rights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Access and Control</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• View and download your personal data</li>
                  <li>• Update or correct your information</li>
                  <li>• Delete your account and data</li>
                  <li>• Export your data in portable format</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Communication Preferences</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Opt out of marketing communications</li>
                  <li>• Manage newsletter subscriptions</li>
                  <li>• Control notification settings</li>
                  <li>• Request communication restrictions</li>
                </ul>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">Exercise Your Rights</h4>
              <p className="text-blue-800 text-sm mb-3">
                To exercise any of these rights, contact our Privacy Officer:
              </p>
              <div className="flex items-center text-blue-800 text-sm">
                <Mail className="h-4 w-4 mr-2" />
                <span>privacy@medifind360.com</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle>Contact Us</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">
              If you have questions about this Privacy Policy or our privacy practices, please contact us:
            </p>

            <div className="space-y-3">
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-gray-400 mr-3" />
                <div>
                  <div className="font-medium">Privacy Officer</div>
                  <div className="text-gray-600">privacy@medifind360.com</div>
                </div>
              </div>

              <div className="flex items-center">
                <FileText className="h-5 w-5 text-gray-400 mr-3" />
                <div>
                  <div className="font-medium">Mailing Address</div>
                  <div className="text-gray-600">
                    MediFind360 Privacy Department
                    <br />
                    123 Healthcare Plaza, Suite 100
                    <br />
                    Miami, FL 33101
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>Policy Updates:</strong> We may update this Privacy Policy periodically. We will notify you of
                significant changes via email or through our platform. Your continued use of our services after such
                modifications constitutes acceptance of the updated policy.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
