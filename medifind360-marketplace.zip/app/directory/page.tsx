"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, MapPin, Star, Phone, Clock, Shield, Filter, Navigation } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const providers = [
  {
    id: 1,
    name: "St. Mary's Medical Center",
    specialty: "General Hospital",
    rating: 4.8,
    reviews: 1247,
    distance: "0.8 miles",
    address: "123 Healthcare Blvd, Miami, FL 33101",
    phone: "(305) 555-0123",
    image: "/images/hospital-exterior.jpg",
    verified: true,
    acceptsInsurance: ["Blue Cross", "Aetna", "Medicare"],
    languages: ["English", "Spanish"],
    wheelchair: true,
    telemedicine: true,
  },
  {
    id: 2,
    name: "Dr. Sarah Johnson - Cardiology",
    specialty: "Cardiology",
    rating: 4.9,
    reviews: 892,
    distance: "1.2 miles",
    address: "456 Heart Center Dr, Miami, FL 33102",
    phone: "(305) 555-0456",
    image: "/images/doctor-cardiology.jpg",
    verified: true,
    acceptsInsurance: ["UnitedHealth", "Cigna", "Medicare"],
    languages: ["English"],
    wheelchair: true,
    telemedicine: false,
  },
  {
    id: 3,
    name: "Miami Imaging Center",
    specialty: "Radiology & Imaging",
    rating: 4.7,
    reviews: 634,
    distance: "2.1 miles",
    address: "789 Scan Street, Miami, FL 33103",
    phone: "(305) 555-0789",
    image: "/images/imaging-center.jpg",
    verified: true,
    acceptsInsurance: ["Blue Cross", "Humana", "Medicaid"],
    languages: ["English", "Spanish", "French"],
    wheelchair: true,
    telemedicine: false,
  },
]

export default function DirectoryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [location, setLocation] = useState("")
  const [specialty, setSpecialty] = useState("")
  const [insurance, setInsurance] = useState("")

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">M</span>
              </div>
              <span className="text-xl font-bold text-gray-900">MediFind360</span>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/directory" className="text-teal-600 font-medium">
                Directory
              </Link>
              <Link href="/equipment" className="text-gray-700 hover:text-teal-600">
                Equipment
              </Link>
              <Link href="/insurance" className="text-gray-700 hover:text-teal-600">
                Insurance
              </Link>
            </nav>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Find Healthcare Providers</h1>

          <div className="grid md:grid-cols-4 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Doctor, clinic, or specialty..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="City, state, or ZIP code"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={specialty} onValueChange={setSpecialty}>
              <SelectTrigger>
                <SelectValue placeholder="Specialty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cardiology">Cardiology</SelectItem>
                <SelectItem value="dermatology">Dermatology</SelectItem>
                <SelectItem value="orthopedics">Orthopedics</SelectItem>
                <SelectItem value="pediatrics">Pediatrics</SelectItem>
                <SelectItem value="radiology">Radiology</SelectItem>
              </SelectContent>
            </Select>

            <Select value={insurance} onValueChange={setInsurance}>
              <SelectTrigger>
                <SelectValue placeholder="Insurance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="blue-cross">Blue Cross Blue Shield</SelectItem>
                <SelectItem value="aetna">Aetna</SelectItem>
                <SelectItem value="united">UnitedHealthcare</SelectItem>
                <SelectItem value="medicare">Medicare</SelectItem>
                <SelectItem value="medicaid">Medicaid</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap gap-4 items-center">
            <Button className="bg-teal-600 hover:bg-teal-700">
              <Search className="h-4 w-4 mr-2" />
              Search Providers
            </Button>
            <Button variant="outline">
              <Navigation className="h-4 w-4 mr-2" />
              Use My Location
            </Button>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              More Filters
            </Button>
          </div>
        </div>

        {/* Results */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-3">Distance</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">Within 5 miles</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">Within 10 miles</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">Within 25 miles</span>
                    </label>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Rating</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">4.5+ stars</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">4.0+ stars</span>
                    </label>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Features</h3>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">Wheelchair Accessible</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">Telemedicine Available</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <Checkbox />
                      <span className="text-sm">Same Day Appointments</span>
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Provider Listings */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">{providers.length} providers found near you</h2>
              <Select defaultValue="distance">
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="distance">Sort by Distance</SelectItem>
                  <SelectItem value="rating">Sort by Rating</SelectItem>
                  <SelectItem value="reviews">Sort by Reviews</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {providers.map((provider) => (
              <Card key={provider.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-48 flex-shrink-0">
                      <Image
                        src={provider.image || "/placeholder.svg"}
                        alt={provider.name}
                        width={300}
                        height={200}
                        className="w-full h-32 object-cover rounded-lg"
                      />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-xl font-semibold text-gray-900 mb-1">
                            {provider.name}
                            {provider.verified && <Shield className="inline h-5 w-5 text-green-500 ml-2" />}
                          </h3>
                          <p className="text-gray-600">{provider.specialty}</p>
                        </div>
                        <Badge variant="secondary">{provider.distance}</Badge>
                      </div>

                      <div className="flex items-center mb-3">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="ml-1 font-medium">{provider.rating}</span>
                          <span className="ml-1 text-gray-500">({provider.reviews} reviews)</span>
                        </div>
                      </div>

                      <p className="text-gray-600 mb-3 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {provider.address}
                      </p>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {provider.acceptsInsurance.slice(0, 2).map((ins) => (
                          <Badge key={ins} variant="outline">
                            {ins}
                          </Badge>
                        ))}
                        {provider.acceptsInsurance.length > 2 && (
                          <Badge variant="outline">+{provider.acceptsInsurance.length - 2} more</Badge>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                        <span className="flex items-center">
                          <Phone className="h-4 w-4 mr-1" />
                          {provider.phone}
                        </span>
                        {provider.wheelchair && (
                          <span className="flex items-center text-green-600">
                            <Shield className="h-4 w-4 mr-1" />
                            Wheelchair Accessible
                          </span>
                        )}
                        {provider.telemedicine && (
                          <span className="flex items-center text-blue-600">
                            <Clock className="h-4 w-4 mr-1" />
                            Telemedicine
                          </span>
                        )}
                      </div>

                      <div className="flex gap-3">
                        <Button className="bg-teal-600 hover:bg-teal-700">View Details</Button>
                        <Button variant="outline">
                          <Phone className="h-4 w-4 mr-2" />
                          Call Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
