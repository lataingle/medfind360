"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Star, ShoppingCart, Heart, Award, Truck, Shield } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const featuredProducts = [
  {
    id: 1,
    name: "Omron Blood Pressure Monitor",
    category: "Diagnostic Equipment",
    price: 89.99,
    originalPrice: 119.99,
    rating: 4.8,
    reviews: 2847,
    image: "/images/blood-pressure-monitor.jpg",
    badge: "Best Seller",
    features: ["Bluetooth Connectivity", "Large Display", "Irregular Heartbeat Detection"],
    affiliate: "amazon",
  },
  {
    id: 2,
    name: "3M Littmann Stethoscope",
    category: "Professional Tools",
    price: 199.99,
    originalPrice: 249.99,
    rating: 4.9,
    reviews: 1523,
    image: "/images/stethoscope.jpg",
    badge: "Expert Pick",
    features: ["Superior Acoustics", "Lightweight", "Dual-Head Design"],
    affiliate: "amazon",
  },
  {
    id: 3,
    name: "Drive Medical Walker",
    category: "Mobility Aids",
    price: 45.99,
    originalPrice: 65.99,
    rating: 4.6,
    reviews: 892,
    image: "/images/walker.jpg",
    badge: "Great Value",
    features: ["Adjustable Height", "Foldable", "Non-Slip Grips"],
    affiliate: "ebay",
  },
  {
    id: 4,
    name: "Pulse Oximeter",
    category: "Monitoring Devices",
    price: 24.99,
    originalPrice: 39.99,
    rating: 4.7,
    reviews: 3421,
    image: "/images/pulse-oximeter.jpg",
    badge: "Top Rated",
    features: ["OLED Display", "Finger Clip Design", "Low Battery Indicator"],
    affiliate: "amazon",
  },
]

const categories = [
  { name: "Diagnostic Equipment", count: 245, icon: "🩺" },
  { name: "Mobility Aids", count: 189, icon: "♿" },
  { name: "Monitoring Devices", count: 156, icon: "📊" },
  { name: "Surgical Instruments", count: 98, icon: "🔧" },
  { name: "Rehabilitation", count: 134, icon: "🏃" },
  { name: "Home Care", count: 267, icon: "🏠" },
]

export default function EquipmentPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [category, setCategory] = useState("")
  const [priceRange, setPriceRange] = useState("")

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">M</span>
              </div>
              <span className="text-xl font-bold text-gray-900">MediFind360</span>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/directory" className="text-gray-700 hover:text-teal-600">
                Directory
              </Link>
              <Link href="/equipment" className="text-teal-600 font-medium">
                Equipment
              </Link>
              <Link href="/insurance" className="text-gray-700 hover:text-teal-600">
                Insurance
              </Link>
            </nav>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-coral-600 to-coral-700 rounded-2xl p-8 mb-8 text-white">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-4xl font-bold mb-4">Medical Equipment Marketplace</h1>
              <p className="text-xl mb-6 text-coral-100">
                Find the best medical equipment from trusted suppliers. Expert recommendations, competitive prices, and
                fast shipping.
              </p>
              <div className="flex items-center space-x-4">
                <Badge className="bg-white text-coral-600">Free Shipping Over $50</Badge>
                <Badge className="bg-white text-coral-600">Expert Support</Badge>
              </div>
            </div>
            <div className="text-center">
              <Image
                src="/images/medical-equipment.jpg"
                alt="Medical equipment collection"
                width={400}
                height={300}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search medical equipment..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="diagnostic">Diagnostic Equipment</SelectItem>
                <SelectItem value="mobility">Mobility Aids</SelectItem>
                <SelectItem value="monitoring">Monitoring Devices</SelectItem>
                <SelectItem value="surgical">Surgical Instruments</SelectItem>
              </SelectContent>
            </Select>

            <Select value={priceRange} onValueChange={setPriceRange}>
              <SelectTrigger>
                <SelectValue placeholder="Price Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-50">$0 - $50</SelectItem>
                <SelectItem value="50-100">$50 - $100</SelectItem>
                <SelectItem value="100-250">$100 - $250</SelectItem>
                <SelectItem value="250+">$250+</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-coral-600 hover:bg-coral-700">Search Products</Button>
          </div>
        </div>

        {/* Categories Grid */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((cat) => (
              <Card key={cat.name} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="text-3xl mb-2">{cat.icon}</div>
                  <h3 className="font-semibold text-sm mb-1">{cat.name}</h3>
                  <p className="text-xs text-gray-500">{cat.count} items</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Featured Products */}
        <Tabs defaultValue="featured" className="mb-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="featured">Featured</TabsTrigger>
            <TabsTrigger value="bestsellers">Best Sellers</TabsTrigger>
            <TabsTrigger value="deals">Deals</TabsTrigger>
            <TabsTrigger value="new">New Arrivals</TabsTrigger>
          </TabsList>

          <TabsContent value="featured" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="p-4">
                    <div className="relative">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={250}
                        height={250}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <Badge className="absolute top-2 left-2 bg-coral-600">{product.badge}</Badge>
                      <Button size="sm" variant="outline" className="absolute top-2 right-2 p-2">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{product.category}</p>

                    <div className="flex items-center mb-2">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        <span className="ml-1 text-sm font-medium">{product.rating}</span>
                        <span className="ml-1 text-sm text-gray-500">({product.reviews})</span>
                      </div>
                    </div>

                    <div className="flex items-center mb-3">
                      <span className="text-2xl font-bold text-coral-600">${product.price}</span>
                      <span className="ml-2 text-sm text-gray-500 line-through">${product.originalPrice}</span>
                    </div>

                    <ul className="text-xs text-gray-600 mb-4 space-y-1">
                      {product.features.slice(0, 2).map((feature) => (
                        <li key={feature} className="flex items-center">
                          <Award className="h-3 w-3 mr-1 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-coral-600 hover:bg-coral-700">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Add to Cart
                      </Button>
                    </div>

                    <div className="flex items-center justify-between mt-3 text-xs text-gray-500">
                      <span className="flex items-center">
                        <Truck className="h-3 w-3 mr-1" />
                        Free shipping
                      </span>
                      <span className="flex items-center">
                        <Shield className="h-3 w-3 mr-1" />
                        Verified seller
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="bestsellers">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-4">Best Selling Medical Equipment</h3>
              <p className="text-gray-600">Our most popular products trusted by healthcare professionals</p>
            </div>
          </TabsContent>

          <TabsContent value="deals">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-4">Special Deals & Discounts</h3>
              <p className="text-gray-600">Limited time offers on quality medical equipment</p>
            </div>
          </TabsContent>

          <TabsContent value="new">
            <div className="text-center py-12">
              <h3 className="text-xl font-semibold mb-4">New Arrivals</h3>
              <p className="text-gray-600">Latest medical equipment and innovations</p>
            </div>
          </TabsContent>
        </Tabs>

        {/* Expert Recommendations */}
        <div className="bg-white rounded-xl p-8 mb-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Expert Recommendations</h2>
            <p className="text-xl text-gray-600">Curated by healthcare professionals for quality and reliability</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="h-6 w-6 text-blue-600 mr-2" />
                  Best for Home Use
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Essential medical equipment recommended for home healthcare monitoring and basic medical needs.
                </p>
                <Button variant="outline" className="w-full">
                  View Collection
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-green-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-6 w-6 text-green-600 mr-2" />
                  Professional Grade
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  High-quality medical equipment trusted by healthcare professionals in clinical settings.
                </p>
                <Button variant="outline" className="w-full">
                  View Collection
                </Button>
              </CardContent>
            </Card>

            <Card className="border-2 border-purple-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="h-6 w-6 text-purple-600 mr-2" />
                  Top Rated
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">
                  Highest-rated medical equipment based on customer reviews and expert evaluations.
                </p>
                <Button variant="outline" className="w-full">
                  View Collection
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
